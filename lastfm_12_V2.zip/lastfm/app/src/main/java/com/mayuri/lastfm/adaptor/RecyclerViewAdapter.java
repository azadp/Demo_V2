package com.mayuri.lastfm.adaptor;


import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.mayuri.lastfm.R;
import com.mayuri.lastfm.pojo.Album;
import com.mayuri.lastfm.ui.WebViewActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import javax.inject.Inject;


public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {

    private ArrayList<Album> albumModels;
    private RecyclerViewAdapter.ClickListener clickListener;
    private Context context;

    @Inject
    public RecyclerViewAdapter(ClickListener clickListener) {
        this.clickListener = clickListener;
        albumModels = new ArrayList<>();
    }

    public interface ClickListener {
        void launchIntent(String RepoName);
    }

    public void setData(ArrayList<Album> albumModels, Context context) {
        this.albumModels = albumModels;
        this.context = context;
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.lastfm_recyclerview, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        final Album albumModelsData = albumModels.get(position);
        holder.txt_albumText.setText(albumModelsData.getName());
        holder.txt_artistText.setText(albumModelsData.getArtist());
        holder.txt_urlData.setText(albumModelsData.getUrl());
        holder.txt_urlData.setPaintFlags(holder.txt_urlData.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);


        try {
            if (albumModelsData.getImage() != null && albumModelsData.getImage().size() > 0) {
                String urlImg = "";
                if (albumModelsData.getImage().size() >= 2) {
                    urlImg = albumModels.get(position).getImage().get(1).getText();

                } else {

                    urlImg = albumModels.get(position).getImage().get(0).getText();

                }
                if (urlImg != null && urlImg.length() > 0) {
                    Picasso.get().load(urlImg).into(holder.imageView);
                }
            }
        } catch (Exception ex) {

        }

        holder.txt_urlData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(context, WebViewActivity.class);
                in.putExtra("urlData", albumModelsData.getUrl());
                context.startActivity(in);
            }
        });
    }


    @Override
    public int getItemCount() {
        return albumModels.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView txt_urlData, txt_artistText, txt_albumText;
        public ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);

            txt_albumText = itemView.findViewById(R.id.txt_albumText);
            txt_urlData = itemView.findViewById(R.id.txt_urlData);
            txt_artistText = itemView.findViewById(R.id.txt_artistText);
            imageView = itemView.findViewById(R.id.imageView);

        }
    }

}
