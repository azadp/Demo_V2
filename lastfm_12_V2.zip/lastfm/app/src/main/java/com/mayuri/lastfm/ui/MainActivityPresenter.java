package com.mayuri.lastfm.ui;

public class MainActivityPresenter implements MainActivityContract.Presenter {
    private MainActivityContract.View view;


    public MainActivityPresenter(MainActivityContract.View view) {
        this.view = view;

    }

    public void sendMessage(String message) {
        if (message != null && !message.isEmpty()) {

            view.clearMessageInput();
        }
    }

    @Override
    public void messageInputTextChanged(String messageInput) {
        if (messageInput == null || messageInput.isEmpty()) {
            view.disableSendButton();
        } else {
            view.enableSendButton();
        }
    }
}
