package com.mayuri.lastfm.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.mayuri.lastfm.MyApplication;
import com.mayuri.lastfm.R;
import com.mayuri.lastfm.adaptor.RecyclerViewAdapter;
import com.mayuri.lastfm.di.component.ApplicationComponent;
import com.mayuri.lastfm.di.component.DaggerApplicationComponent;
import com.mayuri.lastfm.di.component.DaggerMainActivityComponent;
import com.mayuri.lastfm.di.component.MainActivityComponent;
import com.mayuri.lastfm.di.module.ContextModule;
import com.mayuri.lastfm.di.module.MainActivityContextModule;
import com.mayuri.lastfm.di.qualifier.ActivityContext;
import com.mayuri.lastfm.di.qualifier.ApplicationContext;
import com.mayuri.lastfm.network.ApiClient;
import com.mayuri.lastfm.pojo.Album;
import com.mayuri.lastfm.pojo.Example;
import com.mayuri.lastfm.retrofit.APIInterface;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.ClickListener, MainActivityContract.View {

    private RecyclerView recyclerView;
    private MainActivityComponent mainActivityComponent;

    private Button search;
    MainActivityContract.Presenter presenter;
    @Inject
    public RecyclerViewAdapter recyclerViewAdapter;

    @Inject
    public APIInterface apiInterface;

    @Inject
    @ApplicationContext
    public Context mContext;

    @Inject
    @ActivityContext
    public Context activityContext;
    private ProgressDialog dialog;
    private ArrayList<Album> albumModels;
    private String requestUrl, searchTxt;
    private EditText edtxtAlbumName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        search = findViewById(R.id.buttonSearch);
        recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        edtxtAlbumName = findViewById(R.id.edtxtAlbumName);

        //  final SharedPreferences.Editor editor = getSharedPreferences(USER_INPUT, MODE_PRIVATE).edit();


        ApplicationComponent applicationComponent = DaggerApplicationComponent.builder().contextModule(new ContextModule(this)).build();
        applicationComponent.injectApplication(MyApplication.getInstance());

        ApplicationComponent applicationComponent1 = MyApplication.getInstance().getApplicationComponent();
        mainActivityComponent = DaggerMainActivityComponent.builder()
                .mainActivityContextModule(new MainActivityContextModule(this))
                .applicationComponent(applicationComponent)
                .build();

        mainActivityComponent.injectMainActivity(this);

        recyclerViewAdapter = new RecyclerViewAdapter(this);
        recyclerView.setAdapter(recyclerViewAdapter);


        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                searchTxt = edtxtAlbumName.getText().toString().trim();

                if (searchTxt != null && searchTxt.length() > 0) {
                    //new InitialSetData().execute();

                    dialog = new ProgressDialog(MainActivity.this);
                    dialog.setMessage("Please wait..");
                    dialog.show();

                    APIInterface apiService = ApiClient.getClient().create(APIInterface.class);
                    apiService.getDataFromServer("application/json", "application/json", "album.search", searchTxt, "00b49401c799a92996db257a81aaa3a7", "json").enqueue(new Callback<Example>() {
                        @Override
                        public void onResponse(Call<Example> call, Response<Example> response) {

                            try {

                                try {


                                } catch (Exception ex) {

                                }
                                if (response.body() != null) {

                                    albumModels = (ArrayList<Album>) response.body().getResults().getAlbummatches().getAlbum();
                                    System.out.println("SplashActivity.onResponse " + response);
                                    if (albumModels != null && albumModels.size() > 0) {
                                        recyclerViewAdapter.setData(albumModels, MainActivity.this);
                                        Log.e("EM", ":::::::::::::Print:::::::::" + albumModels.size());
                                    }

                                }


                            } catch (Exception ex) {

                            }
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }


                        }

                        @Override
                        public void onFailure(Call<Example> call, Throwable t) {
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                            }
                            t.printStackTrace();

                        }
                    });
                }


            }
        });


    }


    @Override
    public void clearMessageInput() {
        edtxtAlbumName.setText("");
    }

    @Override
    public void enableSendButton() {
        if (!search.isEnabled()) {
            search.setEnabled(true);
            search.setAlpha(1.0f);
        }
    }

    @Override
    public void disableSendButton() {
        if (search.isEnabled()) {
            search.setEnabled(false);
            search.setAlpha(0.5f);
        }
    }


    @Override
    public void launchIntent(String filmName) {

    }

    public void setAdapter(RecyclerViewAdapter recyclerViewAdapter) {
        this.recyclerViewAdapter = recyclerViewAdapter;
    }

    public void setListOfMessages(ArrayList<Album> albumModels) {
        this.albumModels = albumModels;
    }

    public void setPresenter(MainActivityContract.Presenter presenter) {
        this.presenter = presenter;
    }
}
