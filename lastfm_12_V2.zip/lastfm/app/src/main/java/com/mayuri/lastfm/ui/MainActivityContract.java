package com.mayuri.lastfm.ui;

public interface MainActivityContract {
    interface View {


        void clearMessageInput();

        void enableSendButton();

        void disableSendButton();
    }

    interface Presenter {
        void sendMessage(String message);

        void messageInputTextChanged(String messageInput);
    }
}
