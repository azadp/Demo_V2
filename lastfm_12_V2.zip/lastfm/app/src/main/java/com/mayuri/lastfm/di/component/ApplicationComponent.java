package com.mayuri.lastfm.di.component;

import android.content.Context;


import com.mayuri.lastfm.MyApplication;
import com.mayuri.lastfm.di.module.ContextModule;
import com.mayuri.lastfm.di.module.RetrofitModule;
import com.mayuri.lastfm.di.qualifier.ApplicationContext;
import com.mayuri.lastfm.di.scope.ApplicationScope;
import com.mayuri.lastfm.retrofit.APIInterface;

import dagger.Component;

@ApplicationScope
@Component(modules = {ContextModule.class, RetrofitModule.class})
public interface ApplicationComponent {

    public APIInterface getApiInterface();

    @ApplicationContext
    public Context getContext();

    public void injectApplication(MyApplication myApplication);
}
