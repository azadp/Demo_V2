package com.mayuri.lastfm.ui;

import android.widget.Button;
import android.widget.EditText;

import com.mayuri.lastfm.R;
import com.mayuri.lastfm.adaptor.RecyclerViewAdapter;
import com.mayuri.lastfm.pojo.Album;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;

import java.util.ArrayList;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(RobolectricTestRunner.class)
public class MainActivityTest {

    public static final String MESSAGE = "Normal message";
    private MainActivity activity;
    private EditText edtxtAlbumName;
    private Button buttonSearch;
    @Mock
    public RecyclerViewAdapter recyclerViewAdapter;
    @Mock
    ArrayList<Album> listOfMessages;
    @Mock
    private MainActivityContract.Presenter presenter;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        activity = Robolectric.setupActivity(MainActivity.class);
        edtxtAlbumName = activity.findViewById(R.id.edtxtAlbumName);
        buttonSearch = activity.findViewById(R.id.buttonSearch);
        activity.setAdapter(recyclerViewAdapter);
        activity.setListOfMessages(listOfMessages);
        activity.setPresenter(presenter);
        when(listOfMessages.size()).thenReturn(0);
    }

    // Test View

    @Test
    public void clearMessageInput_WasEmpty_ClearedMessageInput() {
        activity.clearMessageInput();
        assertThat(edtxtAlbumName.getText().toString(), is(""));
    }

    @Test
    public void clearMessageInput_WastntEmpty_ClearedMessageInput() {
        edtxtAlbumName.setText("life");
        activity.clearMessageInput();
        assertThat(edtxtAlbumName.getText().toString(), is(""));
    }

    @Test
    public void enableSendButton_WasDisabled_ButtonEnabled() {
        presetSendButtonAsDisabled();
        activity.enableSendButton();
        assertThatSendButtonIsEnabled();
    }

    @Test
    public void enableSendButton_WasEnabled_ButtonEnabled() {
        activity.enableSendButton();
        assertThatSendButtonIsEnabled();
    }

    @Test
    public void disableSendButton_WasEnabled_ButtonDisabled() {
        activity.disableSendButton();
        assertThatSendButtonIsDisabled();
    }

    @Test
    public void disableSendButton_WasDisabled_ButtonDisabled() {
        presetSendButtonAsDisabled();
        activity.disableSendButton();
        assertThatSendButtonIsDisabled();
    }


    private void presetSendButtonAsDisabled() {
        buttonSearch.setEnabled(false);
        buttonSearch.setAlpha(0.5f);
    }

    private void assertThatSendButtonIsEnabled() {
        assertThat(buttonSearch.getAlpha(), is(1.0f));
        assertThat(buttonSearch.isEnabled(), is(true));
    }

    private void assertThatSendButtonIsDisabled() {
        assertThat(buttonSearch.getAlpha(), is(0.5f));
        assertThat(buttonSearch.isEnabled(), is(false));
    }


    // Test Listeners

    @Test
    public void typeSomeText_PassedToPresenter() {
        edtxtAlbumName.setText(MESSAGE);
        verify(presenter).messageInputTextChanged(MESSAGE);
    }

    @Test
    public void pressedSendButton_EmptyInput_PassedEmptyString() {
        buttonSearch.performClick();
        verify(presenter).sendMessage("");
    }

    @Test
    public void pressedSendButton_NormalStringInput_PassedCorrectString() {
        edtxtAlbumName.setText(MESSAGE);
        buttonSearch.performClick();
        verify(presenter).sendMessage(MESSAGE);
    }

}
